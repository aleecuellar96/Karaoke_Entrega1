import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { EditarPage } from '../editar/editar';
import { ReservacionPage } from '../reservacion/reservacion';
import { AlertController } from 'ionic-angular';


@IonicPage()
@Component({
  selector: 'page-reser',
  templateUrl: 'reser.html',
})
export class ReserPage {

  constructor(public navCtrl: NavController, public navParams: NavParams, public alerCtrl: AlertController) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ReserPage');
  }

  nueva(){
    this.navCtrl.push(ReservacionPage);
  }

  editar(){
    this.navCtrl.push(EditarPage);
  }

  items = [
    'Cumpleaños Armando',
    'Graduación',
    'Fin de año'
  ];

  itemSelected(item: string) {
    console.log("Selected Item", item);
  }

  doConfirm() {
    let confirm = this.alerCtrl.create({
      title: '¿Quieres borrar tu evento?',
      message: 'Esto significa que cancelarlo',
      buttons: [
        {
          text: 'No',
          handler: () => {
            console.log('Disagree clicked');
          }
        },
        {
          text: 'Si',
          handler: () => {
            console.log('Agree clicked');
          }
        }
      ]
    });
    confirm.present()
  }

}
