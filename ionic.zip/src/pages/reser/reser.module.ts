import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ReserPage } from './reser';

@NgModule({
  declarations: [
    ReserPage,
  ],
  imports: [
    IonicPageModule.forChild(ReserPage),
  ],
})
export class ReserPageModule {}
