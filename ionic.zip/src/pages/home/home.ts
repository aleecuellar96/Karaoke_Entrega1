import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Platform, ActionSheetController } from 'ionic-angular';
import { SonandoPage } from '../sonando/sonando';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  constructor(public navCtrl: NavController, public platform: Platform,
    public actionsheetCtrl: ActionSheetController) {}

    openMenu() {
        let actionSheet = this.actionsheetCtrl.create({
          buttons: [
            {
              text: 'Cerrar sesión',
              role: 'destructive',
              handler: () => {
                console.log('Delete clicked');
                this.navCtrl.push(SonandoPage);
              }
            }
          ]
        });
        actionSheet.present();
      }
    }
