import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { AlertController } from 'ionic-angular';

@Component({
  selector: 'page-contact',
  templateUrl: 'contact.html'

})
export class ContactPage {
  constructor(public navCtrl: NavController, public alerCtrl: AlertController) {}
  doConfirm() {
    let confirm = this.alerCtrl.create({
      title: '¿Seguro quieres ordenarlo?',
      message: 'Todos los alimentos se agregarán automaticamente a tu cuenta',
      buttons: [
        {
          text: 'No',
          handler: () => {
            console.log('Disagree clicked');
          }
        },
        {
          text: 'Si',
          handler: () => {
            console.log('Agree clicked');
          }
        }
      ]
    });
    confirm.present()
  }

  public evento = {
    month: '',
    timeStarts: '',
    timeEnds: '',
  }
}
