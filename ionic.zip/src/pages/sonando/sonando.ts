import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { HomePage } from '../home/home';
import { AlertController } from 'ionic-angular';


@IonicPage()
@Component({
  selector: 'page-sonando',
  templateUrl: 'sonando.html',
})
export class SonandoPage {

  constructor(public navCtrl: NavController, public navParams: NavParams, public alerCtrl: AlertController) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SonandoPage');
  }

  aInicio(){
    let confirm = this.alerCtrl.create({
      title: 'Conectar a Facebook',
      message: '¿De acuerdo?',
      buttons: [
        {
          text: 'No',
          handler: () => {
            console.log('Disagree clicked');
          }
        },
        {
          text: 'Si',
          handler: () => {
            this.navCtrl.push(HomePage);
            console.log('Agree clicked');
          }
        }
      ]
    });
    confirm.present()
  }

}
