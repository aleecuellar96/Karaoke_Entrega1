import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SonandoPage } from './sonando';

@NgModule({
  declarations: [
    SonandoPage,
  ],
  imports: [
    IonicPageModule.forChild(SonandoPage),
  ],
})
export class SonandoPageModule {}
